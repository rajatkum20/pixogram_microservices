package com.pixogram.demo;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=com.pixogram.demo.UploadMediaApplication.class)
public class UploadMediaApplicationTests {

	
	@Autowired
	public ImageDao ss;
		@Test
		public void contextLoads() {
		}
		@Test
		public void testUser() {
			String expectedName="param";
			assertEquals(expectedName, UploadMedia.getUserNamewithuploadMedia());
		}
		@Test
		public void testRepo() {
			List<UploadMedia> list =new ArrayList<>();
			list= ss.findAll();
			assertEquals(list.get(0).getUsername(),"nav");
			assertEquals(list.get(1).getUsername(),"rajat");
		}
		
}
