package com.pixogram.demo;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UploadMediaController {
	
	UploadMedia upmedia=new UploadMedia();

	@Autowired
	private ImageDao imageDao;
		
	String uname=new String();
	@PostMapping("/upload")
	public void FileUpoad( @RequestParam("Myfile") MultipartFile file,@RequestParam("tags") String tags,@RequestParam("Description")String Description,@RequestParam("title") String title,@RequestParam("username")String username) throws IOException
	{	
		uname=username;
		UploadMedia up=new UploadMedia();
		up.setPic(file.getBytes());
		up.setTitle(title);
		up.setDescription(Description);
		up.setTags(tags);
		byte a[]=file.getBytes();
		byte img[]=Base64.encodeBase64(a);
		String base64enc=new String(img,"UTF-8");
		up.setEncimg(base64enc);
		up.setUsername(username);
		imageDao.save(up);
	}
	
	@GetMapping("/reqImgbyUser")
	public List<UploadMedia> listphotos(){
		List<UploadMedia> listpics=imageDao.findByUsername(uname);
		return listpics;
		
	}
	
	@GetMapping("/showphoto/{id}")/*Gets the id of respective photo*/
	public UploadMedia showphoto(@PathVariable(value="id") Long id) {		
		Optional<UploadMedia> photo=imageDao.findById(id);
		UploadMedia pic=photo.get();
		return pic;
    }
	
	@GetMapping("/Imgbyuser/{username}")
	public List<UploadMedia> listphotobyUser(@PathVariable(value="username")String username)
	{
		List<UploadMedia> listpic=imageDao.findByUsername(username);
		return listpic;
	}
	@GetMapping("/deletephoto/{id}")/*Gets the id of respective photo*/
	public void deletephoto(@PathVariable(value="id") Long id) {		
	imageDao.deleteById(id);
		
    }

}

	
	
