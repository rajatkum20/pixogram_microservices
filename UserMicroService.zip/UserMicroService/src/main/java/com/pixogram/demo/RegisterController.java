package com.pixogram.demo;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



@RestController
@RequestMapping("/user")
public class RegisterController {

	@Autowired
	private UserDao userDao;

	
	@PostMapping(value="/registration",consumes = MediaType.APPLICATION_JSON_VALUE)
	public void addUser(@RequestBody RegisterUser registeruser)
	{			userDao.save(registeruser);
			
	}
	
	@GetMapping("/listUsers")
				public List<RegisterUser> listAllusers()
				{
				List<RegisterUser> listusers=userDao.findAll();
				return listusers;
					
				}
			    
    @PostMapping("/accupdate")
	public void register(@RequestParam("username")String username,@RequestParam("email")String email,@RequestParam("contact")String contact,@RequestParam("password")String password)
	{
			RegisterUser u=new RegisterUser();
					u=userDao.findByUname(username);
					u.setEmail(email);
					u.setContact(contact);
					u.setPassword(password);
					userDao.save(u);
				
					
				}
				


	
}
