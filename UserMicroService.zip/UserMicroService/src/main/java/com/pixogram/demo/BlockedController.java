package com.pixogram.demo;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class BlockedController {
	@Autowired
	private UserDao userDao;
	
	Optional<RegisterUser> ll ;
	
	 Set<Long> BlockedList=new HashSet<Long>();
	final Set<String>userBlockedList=new HashSet<String>();
	
	String uname=new String();
	String storeCurrUser=new String();
	@GetMapping("/blockuser")
	public void blockinit(@RequestParam("username") String username)
	{
		uname=username;
		System.out.println("Uname printing test"+username);
	}
	@PostMapping("block/{username1}") 
	public List<RegisterUser> block(@PathVariable("username1")String username1) {
		
		  
          RegisterUser loggedInUser=userDao.findByUname(uname); //geetings details using username
          Long loggedin=loggedInUser.getId();		//gettingIdofLoggedUSer
          RegisterUser user_id=userDao.findByUname(username1);
          Long id=user_id.getId();
          Optional<RegisterUser> user=userDao.findById(id); //
          
          loggedInUser.getBlocked().add(user.get());
          if(loggedInUser.getFollowing().contains(user.get()))
          {        		
          loggedInUser.getFollowing().remove(user.get());
          }
          userDao.save(loggedInUser);
          BlockedList= userDao.findBlockUsers(loggedin);         
          
          List<RegisterUser>usersBlocked=userDao.findAllById(BlockedList);
          return usersBlocked;
	}
	
	@GetMapping("/block")
	public List<RegisterUser> blockedUser(@RequestParam("username") String username)
	{
		storeCurrUser=username;
		System.out.println("Uname is"+username);
		RegisterUser loggedInUser=userDao.findByUname(username); 
		  Long loggedin=loggedInUser.getId();
		  BlockedList= userDao.findBlockUsers(loggedin);
		  List<RegisterUser>usersBlocked=userDao.findAllById(BlockedList);
		  return usersBlocked;
		
	}
	@PostMapping("/unblock")
	public void unblock(@RequestParam("id")String id,@RequestParam("username")String username)
	{
		long id1=Long.parseLong(id);
        RegisterUser loggedInUser=userDao.findByUname(username); //gettings details using username
        Long loggedin=loggedInUser.getId();		//gettingIdofLoggedUser
        Optional<RegisterUser> user=userDao.findById(id1);
        loggedInUser.getBlocked().remove(user.get());
         userDao.save(loggedInUser);
		
	}
	}

