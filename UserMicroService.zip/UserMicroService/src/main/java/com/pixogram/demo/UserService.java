package com.pixogram.demo;

public interface UserService {

	public RegisterUser findByUnameAndPassword(String uname, String psw);
	public RegisterUser findByUname(String uname);
	public RegisterUser addUser(RegisterUser user);

}
