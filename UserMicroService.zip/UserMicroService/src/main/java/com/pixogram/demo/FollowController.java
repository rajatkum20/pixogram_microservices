package com.pixogram.demo;

import java.util.ArrayList;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class FollowController {
	@Autowired
	private UserDao userDao;

	Set<Long> useridList=new HashSet<Long>();
	Set<Long> useridListnew=new HashSet<Long>();
	Optional<RegisterUser> ll ;
	List<RegisterUser> followers=new ArrayList<RegisterUser>();
	List<RegisterUser> followersNew=new ArrayList<RegisterUser>();
	final List<String>userNamelist=new ArrayList<String>();
	
	String uname=new String();
	@GetMapping("/Follow")
    public List<RegisterUser> follow12(@RequestParam("username") String username) 
    {
					uname=username;
                    RegisterUser loggedInUser=userDao.findByUname(username);
                	Long loggedin=loggedInUser.getId();
                	useridList= userDao.findFollowingUsers(loggedin);
                    List<RegisterUser> data=userDao.findAll();
                    Set<Long>userBlockList=userDao.findBlockUsers(loggedin);
                    List<RegisterUser> blockedUsers=userDao.findAllById(userBlockList);
                                                      	       
                   	List<Long> list1=new ArrayList<Long>();
                   	List<Long> list2=new ArrayList<Long>();
                   	for(int i=0;i<data.size();i++)
                   	{
                   	list1.add(data.get(i).getId());
                   	}
                	for(int i=0;i<blockedUsers.size();i++)
                   	{
                   	list2.add(blockedUsers.get(i).getId());
                   	}
                	list1.removeAll(list2);
                	list1.remove(loggedin);
                	List<RegisterUser> userwithblock=userDao.findAllById(list1);
					return userwithblock;
                          
                               
    }
	@PostMapping("/followers/{id}")
	public List<RegisterUser> followw(@PathVariable("id") Long id,ModelMap map) 
    {

	         RegisterUser loggedInUser=userDao.findByUname(uname); //geetings details using username
                    Long loggedin=loggedInUser.getId();		//gettingIdofLoggedUSer
                    Optional<RegisterUser> user=userDao.findById(id); //
                    loggedInUser.getFollowing().add(user.get());
                    userDao.save(loggedInUser);
                   	useridList= userDao.findFollowingUsers(loggedin);
                   	
                   	followers=userDao.findAllById(useridList);
                                  	
                   	return followers;
    

    }
	
	@RequestMapping("/followers")
	public List<RegisterUser>  openFollowers(@RequestParam("username")String username)
	{
		RegisterUser loggedInUser=userDao.findByUname(username);
		Long loggedIn=loggedInUser.getId();
		useridListnew=userDao.findFollowingUsers(loggedIn);
		followersNew=userDao.findAllById(useridListnew);
		return followersNew;
	}
	
	@RequestMapping("/unfollow/{id}")
	public void unfollow(@PathVariable("id") Long id)
	{
		
        RegisterUser loggedInUser=userDao.findByUname(uname); //geetings details using username
        Long loggedin=loggedInUser.getId();		//gettingIdofLoggedUSer
        Optional<RegisterUser> user=userDao.findById(id);
        loggedInUser.getFollowing().remove(user.get());
        userDao.save(loggedInUser);
      
	
	}
}


