package com.pixogram.demo;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "RegisterUser1")
public  class RegisterUser  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	@Column(name = "uname")
	private String uname;
	
	private String password;
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
	private String contact;
	
	private int isBlocked=0;
	
	
	@OneToMany(mappedBy = "registerUser",cascade = CascadeType.PERSIST)
	private Set<Comments> comments;
	
	@JsonIgnore
	@ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.PERSIST)
	@JoinTable(name = "relation",
	joinColumns = @JoinColumn(name = "user_id"),
	inverseJoinColumns = @JoinColumn(name = "following_id"))
	private Set<RegisterUser> following;

	@JsonIgnore
	@ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.PERSIST)
	@JoinTable(name="block",
	joinColumns = @JoinColumn(name="user_id"),
	inverseJoinColumns = @JoinColumn(name="blocked_id"))
	private Set<RegisterUser> blocked;
	
	
	public Set<Comments> getComments() {
		return comments;
	}

	public void setComments(Set<Comments> comments) {
		this.comments = comments;
	}


	public Set<RegisterUser> getBlocked() {
		return blocked;
	}

	public void setBlocked(Set<RegisterUser> blocked) {
		this.blocked = blocked;
	}

	public int getIsBlocked() {
		return isBlocked;
	}

	public Set<RegisterUser> getFollowing() {
		return following;
	}

	public void setFollowing(Set<RegisterUser> following) {
		this.following = following;
	}

	public void setIsBlocked(int isBlocked) {
		this.isBlocked = isBlocked;
	}

	private String email;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public static Object getUserNamewithUser() {
		// TODO Auto-generated method stub
		return "rajat";
	}

}
