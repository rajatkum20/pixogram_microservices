
package com.example.demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="media",url="http://localhost:7001/")
public interface UploadImages {	
	
@GetMapping("/reqImgbyUser")
public List<UploadMediaModel> getAllPicsByusername();

@GetMapping("/showphoto/{id}")
public UploadMediaModel getImagebyId(@PathVariable("id") Long id);

@GetMapping("/deletephoto/{id}")
public void deletebyId(@PathVariable("id") Long id);

@GetMapping("/Imgbyuser/{username}")
public List<UploadMediaModel> getImagebyName(@PathVariable("username")String username);
}
