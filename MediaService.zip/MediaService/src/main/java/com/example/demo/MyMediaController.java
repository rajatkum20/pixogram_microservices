package com.example.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.codec.binary.Base64;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class MyMediaController {
	
	@Autowired
	private UploadImages uploadproxy;
	

	@RequestMapping("/mymediapic")
    public List<UploadMediaModel> getfilterpg() 
    {                               
                    List<UploadMediaModel> data=uploadproxy.getAllPicsByusername();
		 		                     
                    return data;                        

    }
	@RequestMapping("/photosbyid/{id}")
	public UploadMediaModel getbyId(@PathVariable("id")long id)
	{
		 UploadMediaModel data2=uploadproxy.getImagebyId(id);
		return data2;
	}
	@RequestMapping("/picsbyname/{username}")
	public List<UploadMediaModel> getImaages(@PathVariable("username")String username)
	{
		List<UploadMediaModel> datanew=uploadproxy.getImagebyName(username);
		return datanew;
	}
	
	@RequestMapping("/deletepic/{id}")
	public void delete(@PathVariable("id")Long id)
	{
		uploadproxy.deletebyId(id);
	}
}
